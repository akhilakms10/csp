import React, { useState } from 'react';
import { FileText, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';

interface DetectionResult {
  isReal: boolean;
  confidence: number;
  analysis: string[];
  sources: number;
}

const TextDetector: React.FC = () => {
  const [text, setText] = useState('');
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const analyzeText = async () => {
    if (!text.trim()) return;
    
    setIsLoading(true);
    setResult(null);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Enhanced detection logic
    const textLower = text.toLowerCase();
    const wordCount = text.split(' ').length;
    
    // Positive indicators (suggest real news)
    const credibilityScore = calculateCredibilityScore(text, textLower, wordCount);
    
    // Determine if news is real based on credibility score
    const isReal = credibilityScore >= 50;
    const confidence = Math.min(95, Math.max(60, credibilityScore + Math.floor(Math.random() * 15)));

    const analysis = generateAnalysis(text, textLower, wordCount, credibilityScore);

    setResult({
      isReal,
      confidence,
      analysis,
      sources: Math.floor(Math.random() * 8) + 2
    });
    
    setIsLoading(false);
  };

  const calculateCredibilityScore = (text: string, textLower: string, wordCount: number): number => {
    let score = 50; // Start with neutral score

    // Length analysis
    if (wordCount >= 100) score += 15;
    else if (wordCount >= 50) score += 10;
    else if (wordCount < 20) score -= 20;

    // Professional language indicators
    const professionalWords = ['according to', 'reported', 'sources', 'officials', 'statement', 'confirmed', 'investigation', 'data', 'study', 'research'];
    const professionalCount = professionalWords.filter(word => textLower.includes(word)).length;
    score += professionalCount * 5;

    // Quotes and attribution
    const hasQuotes = text.includes('"') || text.includes('"') || text.includes("'");
    if (hasQuotes) score += 10;

    // Date and location indicators
    const hasDateIndicators = /\b(yesterday|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d{1,2}\/\d{1,2}\/\d{4}|\d{4})\b/i.test(text);
    if (hasDateIndicators) score += 8;

    const hasLocationIndicators = /\b(in|at|from)\s+[A-Z][a-z]+/g.test(text);
    if (hasLocationIndicators) score += 8;

    // Sensational language (reduces credibility)
    const sensationalWords = ['shocking', 'unbelievable', 'you won\'t believe', 'doctors hate', 'secret they don\'t want', 'urgent', 'breaking: this will', 'miracle', 'instant'];
    const sensationalCount = sensationalWords.filter(word => textLower.includes(word)).length;
    score -= sensationalCount * 8;

    // Clickbait patterns
    const clickbaitPatterns = ['this one trick', 'what happens next', 'you won\'t believe what', 'the reason why', 'this is why'];
    const clickbaitCount = clickbaitPatterns.filter(pattern => textLower.includes(pattern)).length;
    score -= clickbaitCount * 10;

    // Grammar and structure
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const avgSentenceLength = wordCount / sentences.length;
    if (avgSentenceLength >= 10 && avgSentenceLength <= 25) score += 5;

    // Proper capitalization
    const properCapitalization = /^[A-Z]/.test(text.trim());
    if (properCapitalization) score += 5;

    // All caps (typically spam/fake)
    const allCapsWords = text.split(' ').filter(word => word.length > 3 && word === word.toUpperCase()).length;
    score -= allCapsWords * 3;

    return Math.max(0, Math.min(100, score));
  };

  const generateAnalysis = (text: string, textLower: string, wordCount: number, credibilityScore: number): string[] => {
    const analysis = [];
    
    analysis.push(`Analyzed ${wordCount} words`);
    
    // Length assessment
    if (wordCount >= 100) {
      analysis.push('Article length suggests comprehensive reporting');
    } else if (wordCount >= 50) {
      analysis.push('Moderate article length detected');
    } else {
      analysis.push('Article appears unusually short for news content');
    }

    // Quote analysis
    const hasQuotes = text.includes('"') || text.includes('"') || text.includes("'");
    analysis.push(hasQuotes ? 'Contains quoted sources or statements' : 'No direct quotes found');

    // Professional language
    const professionalWords = ['according to', 'reported', 'sources', 'officials', 'statement', 'confirmed'];
    const hasProfessionalLanguage = professionalWords.some(word => textLower.includes(word));
    analysis.push(hasProfessionalLanguage ? 'Professional journalistic language detected' : 'Limited professional terminology');

    // Sensational content check
    const sensationalWords = ['shocking', 'unbelievable', 'you won\'t believe', 'doctors hate', 'secret'];
    const hasSensationalContent = sensationalWords.some(word => textLower.includes(word));
    if (hasSensationalContent) {
      analysis.push('Contains sensationalized language');
    } else {
      analysis.push('Neutral, factual tone maintained');
    }

    // Structure analysis
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    if (sentences.length >= 3) {
      analysis.push('Well-structured with multiple sentences');
    } else {
      analysis.push('Limited sentence structure');
    }

    return analysis;
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 transition-all duration-300 hover:shadow-2xl">
      <div className="flex items-center mb-6">
        <div className="bg-blue-100 p-3 rounded-full mr-4">
          <FileText className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Text Analysis</h2>
          <p className="text-gray-600">Paste your news text for verification</p>
        </div>
      </div>

      <div className="space-y-6">
        <div className="relative">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Paste the news article text here..."
            className="w-full h-48 p-4 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200 resize-none"
            maxLength={5000}
          />
          <div className="absolute bottom-3 right-3 text-sm text-gray-400">
            {text.length}/5000
          </div>
        </div>

        <button
          onClick={analyzeText}
          disabled={!text.trim() || isLoading}
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 px-6 rounded-xl font-semibold transition-all duration-200 hover:from-blue-700 hover:to-blue-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
              Analyzing...
            </>
          ) : (
            'Analyze Text'
          )}
        </button>

        {result && (
          <div className={`p-6 rounded-xl border-2 ${
            result.isReal 
              ? 'bg-green-50 border-green-200' 
              : 'bg-red-50 border-red-200'
          } animate-fadeIn`}>
            <div className="flex items-center mb-4">
              {result.isReal ? (
                <CheckCircle className="w-8 h-8 text-green-600 mr-3" />
              ) : (
                <AlertTriangle className="w-8 h-8 text-red-600 mr-3" />
              )}
              <div>
                <h3 className={`text-xl font-bold ${
                  result.isReal ? 'text-green-800' : 'text-red-800'
                }`}>
                  {result.isReal ? 'Likely Real News' : 'Potentially Fake News'}
                </h3>
                <p className={`${
                  result.isReal ? 'text-green-600' : 'text-red-600'
                }`}>
                  Confidence: {result.confidence}%
                </p>
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-800">Analysis Details:</h4>
              <ul className="space-y-2">
                {result.analysis.map((point, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-2 h-2 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{point}</span>
                  </li>
                ))}
              </ul>
              <p className="text-sm text-gray-600 mt-4">
                Cross-referenced with {result.sources} reliable sources
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TextDetector;