import React, { useState } from 'react';
import { Link, Globe, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';

interface URLResult {
  isReal: boolean;
  confidence: number;
  domain: string;
  analysis: string[];
  reputation: string;
}

const URLDetector: React.FC = () => {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<URLResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const isValidURL = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  const analyzeURL = async () => {
    if (!url.trim() || !isValidURL(url)) return;
    
    setIsLoading(true);
    setResult(null);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2500));

    try {
      const urlObj = new URL(url);
      const domain = urlObj.hostname.toLowerCase();
      
      // Calculate credibility score for the domain
      const credibilityScore = calculateDomainCredibility(domain, urlObj);
      
      const isReal = credibilityScore >= 50;
      const confidence = Math.min(95, Math.max(60, credibilityScore + Math.floor(Math.random() * 10)));

      let reputation;
      if (credibilityScore >= 80) {
        reputation = 'Highly Trusted';
      } else if (credibilityScore >= 60) {
        reputation = 'Moderately Trusted';
      } else if (credibilityScore >= 40) {
        reputation = 'Unverified';
      } else {
        reputation = 'Questionable';
      }

      const analysis = generateDomainAnalysis(domain, urlObj, credibilityScore);

      setResult({
        isReal,
        confidence,
        domain,
        analysis,
        reputation
      });
    } catch (error) {
      console.error('URL analysis error:', error);
    }
    
    setIsLoading(false);
  };

  const calculateDomainCredibility = (domain: string, urlObj: URL): number => {
    let score = 50; // Start with neutral score

    // Highly trusted news sources
    const trustedDomains = [
      'bbc.com', 'bbc.co.uk', 'reuters.com', 'apnews.com', 'npr.org', 
      'cnn.com', 'nytimes.com', 'washingtonpost.com', 'theguardian.com',
      'wsj.com', 'usatoday.com', 'abcnews.go.com', 'cbsnews.com',
      'nbcnews.com', 'pbs.org', 'time.com', 'newsweek.com', 'bloomberg.com',
      'economist.com', 'ft.com', 'politico.com', 'axios.com'
    ];

    // Moderately trusted sources
    const moderatelyTrusted = [
      'yahoo.com', 'msn.com', 'google.com', 'wikipedia.org',
      'huffpost.com', 'buzzfeednews.com', 'vox.com', 'slate.com'
    ];

    // Known fake/satirical news domains
    const untrustedDomains = [
      'theonion.com', 'babylonbee.com', 'fakenews.com', 'clickbait.net',
      'totally-real-news.org', 'fake-news-site.com', 'satirenews.net'
    ];

    // Check against trusted domains
    if (trustedDomains.some(trusted => domain.includes(trusted))) {
      score += 35;
    } else if (moderatelyTrusted.some(moderate => domain.includes(moderate))) {
      score += 15;
    } else if (untrustedDomains.some(untrusted => domain.includes(untrusted))) {
      score -= 40;
    }

    // HTTPS check
    if (urlObj.protocol === 'https:') {
      score += 10;
    } else {
      score -= 15;
    }

    // Domain structure analysis
    const domainParts = domain.split('.');
    
    // Suspicious patterns in domain
    const suspiciousPatterns = [
      'fake', 'hoax', 'satire', 'parody', 'clickbait', 'buzz', 'viral',
      'breaking', 'urgent', 'secret', 'exposed', 'truth', 'real-news'
    ];
    
    const hasSuspiciousPattern = suspiciousPatterns.some(pattern => 
      domain.includes(pattern)
    );
    
    if (hasSuspiciousPattern) {
      score -= 20;
    }

    // Check for proper TLD
    const legitimateTLDs = ['.com', '.org', '.net', '.edu', '.gov', '.co.uk', '.ca', '.au'];
    const hasLegitimateTLD = legitimateTLDs.some(tld => domain.endsWith(tld));
    
    if (hasLegitimateTLD) {
      score += 5;
    } else {
      score -= 10;
    }

    // Domain length (very long domains are often suspicious)
    if (domain.length > 30) {
      score -= 10;
    } else if (domain.length < 15) {
      score += 5;
    }

    // Multiple subdomains can be suspicious
    if (domainParts.length > 3) {
      score -= 5;
    }

    return Math.max(0, Math.min(100, score));
  };

  const generateDomainAnalysis = (domain: string, urlObj: URL, credibilityScore: number): string[] => {
    const analysis = [];
    
    analysis.push(`Domain: ${domain}`);
    
    // HTTPS analysis
    if (urlObj.protocol === 'https:') {
      analysis.push('Secure HTTPS connection verified');
    } else {
      analysis.push('Warning: Insecure HTTP connection');
    }

    // Domain age simulation (in real implementation, this would use WHOIS data)
    const simulatedAge = Math.floor(Math.random() * 15) + 1;
    analysis.push(`Estimated domain age: ${simulatedAge} years`);

    // SSL certificate
    analysis.push(`SSL certificate: ${urlObj.protocol === 'https:' ? 'Valid and verified' : 'Not found or invalid'}`);

    // Trust level analysis
    const trustedDomains = [
      'bbc.com', 'reuters.com', 'apnews.com', 'npr.org', 'cnn.com',
      'nytimes.com', 'washingtonpost.com', 'theguardian.com'
    ];
    
    if (trustedDomains.some(trusted => domain.includes(trusted))) {
      analysis.push('Listed in verified news sources database');
    } else if (credibilityScore >= 60) {
      analysis.push('Domain passes credibility checks');
    } else {
      analysis.push('Domain requires additional verification');
    }

    // Domain structure
    const domainParts = domain.split('.');
    if (domainParts.length <= 3) {
      analysis.push('Standard domain structure');
    } else {
      analysis.push('Complex subdomain structure detected');
    }

    return analysis;
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 transition-all duration-300 hover:shadow-2xl">
      <div className="flex items-center mb-6">
        <div className="bg-purple-100 p-3 rounded-full mr-4">
          <Globe className="w-6 h-6 text-purple-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-800">URL Verification</h2>
          <p className="text-gray-600">Check news articles by URL</p>
        </div>
      </div>

      <div className="space-y-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Link className="w-5 h-5 text-gray-400" />
          </div>
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://example.com/news-article"
            className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:ring-4 focus:ring-purple-100 transition-all duration-200"
          />
        </div>

        <button
          onClick={analyzeURL}
          disabled={!url.trim() || !isValidURL(url) || isLoading}
          className="w-full bg-gradient-to-r from-purple-600 to-purple-700 text-white py-4 px-6 rounded-xl font-semibold transition-all duration-200 hover:from-purple-700 hover:to-purple-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
              Verifying...
            </>
          ) : (
            'Verify URL'
          )}
        </button>

        {!isValidURL(url) && url.trim() && (
          <p className="text-red-500 text-sm">Please enter a valid URL</p>
        )}

        {result && (
          <div className={`p-6 rounded-xl border-2 ${
            result.isReal 
              ? 'bg-green-50 border-green-200' 
              : 'bg-red-50 border-red-200'
          } animate-fadeIn`}>
            <div className="flex items-center mb-4">
              {result.isReal ? (
                <CheckCircle className="w-8 h-8 text-green-600 mr-3" />
              ) : (
                <AlertTriangle className="w-8 h-8 text-red-600 mr-3" />
              )}
              <div>
                <h3 className={`text-xl font-bold ${
                  result.isReal ? 'text-green-800' : 'text-red-800'
                }`}>
                  {result.isReal ? 'Trusted Source' : 'Unverified Source'}
                </h3>
                <p className={`${
                  result.isReal ? 'text-green-600' : 'text-red-600'
                }`}>
                  Confidence: {result.confidence}%
                </p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-4">
                <span className="font-semibold text-gray-800">Domain Reputation:</span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  result.reputation === 'Highly Trusted' 
                    ? 'bg-green-100 text-green-800'
                    : result.reputation === 'Moderately Trusted'
                      ? 'bg-yellow-100 text-yellow-800'
                      : result.reputation === 'Unverified'
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-red-100 text-red-800'
                }`}>
                  {result.reputation}
                </span>
              </div>
              
              <h4 className="font-semibold text-gray-800">Technical Analysis:</h4>
              <ul className="space-y-2">
                {result.analysis.map((point, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-2 h-2 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default URLDetector;