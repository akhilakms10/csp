import React from 'react';
import { Shield, Zap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="text-center mb-12">
      <div className="flex items-center justify-center mb-4">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 rounded-2xl mr-4">
          <Shield className="w-12 h-12 text-white" />
        </div>
        <div className="text-left">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            VeriFact
          </h1>
          <p className="text-gray-600 text-lg">Advanced Fake News Detection</p>
        </div>
      </div>
      
      <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
        Harness the power of artificial intelligence to verify news authenticity. 
        Our advanced algorithms analyze text patterns, source credibility, and linguistic markers 
        to help you distinguish between real and fake news.
      </p>
      
      <div className="flex items-center justify-center mt-6 space-x-6">
        <div className="flex items-center text-green-600">
          <Zap className="w-5 h-5 mr-2" />
          <span className="font-medium">Real-time Analysis</span>
        </div>
        <div className="flex items-center text-blue-600">
          <Shield className="w-5 h-5 mr-2" />
          <span className="font-medium">AI-Powered Detection</span>
        </div>
      </div>
    </header>
  );
};

export default Header;