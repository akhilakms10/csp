import React from 'react';
import Header from './components/Header';
import TextDetector from './components/TextDetector';
import URLDetector from './components/URLDetector';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      <div className="container mx-auto px-4 py-12 max-w-7xl">
        <Header />
        
        <div className="grid lg:grid-cols-2 gap-8">
          <TextDetector />
          <URLDetector />
        </div>
        
        <footer className="mt-16 text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">How It Works</h3>
            <div className="grid md:grid-cols-3 gap-6 text-left">
              <div className="space-y-2">
                <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-bold text-lg">1</span>
                </div>
                <h4 className="font-semibold text-gray-800 text-center">Submit Content</h4>
                <p className="text-gray-600 text-sm text-center">
                  Paste news text or provide a URL to analyze
                </p>
              </div>
              <div className="space-y-2">
                <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-purple-600 font-bold text-lg">2</span>
                </div>
                <h4 className="font-semibold text-gray-800 text-center">AI Analysis</h4>
                <p className="text-gray-600 text-sm text-center">
                  Our algorithms examine patterns and source credibility
                </p>
              </div>
              <div className="space-y-2">
                <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-green-600 font-bold text-lg">3</span>
                </div>
                <h4 className="font-semibold text-gray-800 text-center">Get Results</h4>
                <p className="text-gray-600 text-sm text-center">
                  Receive detailed analysis with confidence scores
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 text-gray-600">
            <p className="text-sm">
              © 2025 VeriFact. This is a demonstration of fake news detection technology.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;